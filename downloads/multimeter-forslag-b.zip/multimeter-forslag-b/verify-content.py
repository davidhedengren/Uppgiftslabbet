import json, re, unittest
from pathlib import Path
qs=json.loads((Path(__file__).parent/'uppgifter.json').read_text())
class MultimeterReference(unittest.TestCase):
 def test_figures_and_metadata(self):
  self.assertEqual(len(qs),16)
  self.assertEqual(len({q['id'] for q in qs}),16)
  for q in qs:
   self.assertIn('<svg',q['figure'])
   self.assertTrue(q['miniräknare']);self.assertFalse(q['geogebra'])
   self.assertEqual(len(q['options']),len(set(q['options'])))
   self.assertTrue(0 <= q['correct'] < len(q['options']))
 def test_reference_model(self):
  for q in [q for q in qs[5:] if q['id'] != 'MM-B12']:
   self.assertIn('4000 µA',q['figure']);self.assertIn('400 mA',q['figure'])
   self.assertIn('COM',q['figure']);self.assertIn('10A',q['figure'])
   self.assertNotIn('200 mA',json.dumps(q,ensure_ascii=False))
  self.assertEqual(qs[5]['options'][qs[5]['correct']],'COM och µA mA / V Ω Hz')
 def test_ranges_and_connections(self):
  self.assertLess(85,400)
  self.assertGreater(.65*1000,400)
  self.assertLess(250,4000)
  self.assertLess(6/300*1000,400)
  self.assertGreater(6/300*1_000_000,4000)
  self.assertEqual(qs[13]['options'][qs[13]['correct']],'Flytta sladden från högra uttaget till 10A och vrida till 10 A.')
  self.assertIn('i serie',qs[14]['options'][qs[14]['correct']])
 def test_no_untaught_terms_or_colour_rules(self):
  for q in qs:
   student=json.dumps(q,ensure_ascii=False)
   self.assertNotRegex(student,r'(?i)\b(?:DC|AC|likström|växelström|likspänning|växelspänning|röd|röda|svart|svarta)\b')
 def test_both_sockets_are_unrevealed(self):
  for i in [5,7,8,14]:
   q=qs[i]
   self.assertNotIn('stroke="#cf3931"',q['figure'])
   self.assertNotIn('stroke="#181c20"',q['figure'])
   self.assertEqual(len(q['options']),len(set(q['options'])))
   self.assertIn('COM',q['options'][q['correct']])
 def test_adjacent_points(self):
  # Independent node-potential example with positive series resistances.
  current=6/(100+200)
  potentials={'A':6,'E':6,'B':current*200,'F':current*200,'C':0,'D':0}
  for a,b in [('A','E'),('B','F')]:self.assertEqual(potentials[a]-potentials[b],0)
  self.assertEqual(qs[0]['options'][qs[0]['correct']],'B och C')
  self.assertEqual(qs[1]['options'][qs[1]['correct']],'A och C')
  self.assertEqual(qs[11]['options'][qs[11]['correct']],'0 V')
  for i in [0,1]:
   self.assertIn('A och E',qs[i]['options']);self.assertIn('B och F',qs[i]['options'])
if __name__=='__main__':unittest.main()
