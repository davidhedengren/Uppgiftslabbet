import json, math, html
from pathlib import Path
out=Path(__file__).resolve().parent
def text(x,y,s,size=18,color='#292d31',anchor='middle'):
 return f'<text x="{x}" y="{y}" text-anchor="{anchor}" font-family="Arial,sans-serif" font-size="{size}" fill="{color}">{html.escape(s)}</text>'
def line(x1,y1,x2,y2,col='#292d31',w=3):return f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{col}" stroke-width="{w}"/>'
def svg(body,label,w=520,h=340):return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}" role="img" aria-label="{html.escape(label,quote=True)}"><rect width="{w}" height="{h}" fill="white"/>{body}</svg>'
def node(x,y,label):return f'<circle cx="{x}" cy="{y}" r="5" fill="#db9f00"/>'+text(x,y-17,label,20,'#292d31')
def resistor(x,y,label):return f'<rect x="{x}" y="{y-12}" width="60" height="24" fill="white" stroke="#292d31" stroke-width="3"/>'+text(x+30,y-26,label)
def source(x,y,label='6 V'):
 return f'<circle cx="{x}" cy="{y}" r="29" fill="white" stroke="#292d31" stroke-width="3"/>'+text(x,y-7,'+',18)+text(x,y+20,'−',20)+text(x-41,y+5,label,17,anchor='end')
def series(values=False):
 b=line(90,75,465,75)+line(465,75,465,255)+line(465,255,90,255)+line(90,75,90,136)+line(90,194,90,255)+source(90,165)
 b+=resistor(180,75,'R₁')+resistor(340,75,'R₂')
 for x,l in [(115,'A'),(150,'E'),(270,'B'),(305,'F'),(430,'C')]:b+=node(x,75,l)
 b+=node(265,255,'D')
 return svg(b,'Två seriekopplade motstånd. A och E bredvid varandra före R1, B och F bredvid varandra mellan R1 och R2, C efter R2 och D på återledningen.')
def parallel():
 b=line(90,60,450,60)+line(450,60,450,280)+line(450,280,90,280)+line(90,60,90,141)+line(90,199,90,280)+source(90,170)
 # split at left rail x170; top line feeds left rail; no top-to-right short!
 b=line(90,60,170,60)+line(170,60,170,220)+line(170,120,450,120)+line(170,220,450,220)+line(450,120,450,280)+line(450,280,90,280)+line(90,60,90,141)+line(90,199,90,280)+source(90,170)
 b+=resistor(290,120,'R₁')+resistor(290,220,'R₂')
 for x,y,l in [(130,60,'P'),(225,120,'Q'),(225,220,'R')]:b+=node(x,y,l)
 for x,y in [(170,120),(450,220)]:b+=f'<circle cx="{x}" cy="{y}" r="4" fill="#292d31"/>'
 return svg(b,'Två parallella motstånd. P i huvudledningen, Q i grenen med R1, R i grenen med R2.')
def meter(display='',setting='OFF',red=None,black=False,unit='',mode=''):
 # Same three sockets and selector markings as the supplied reference.
 ink='#f3f5f7';blue='#9bc6ff'
 b='<rect x="55" y="18" width="370" height="535" rx="42" fill="#f5b900"/><rect x="74" y="37" width="332" height="497" rx="28" fill="#292d31"/>'
 b+='<rect x="99" y="60" width="282" height="85" rx="9" fill="#c6d1bc" stroke="#11171b" stroke-width="4"/>'
 b+=text(118,83,mode,13,'#172a30',anchor='start')+text(118,132,unit,14,'#172a30',anchor='start')
 b+=f'<text x="357" y="115" text-anchor="end" font-family="monospace" font-size="39" font-weight="700" fill="#172a30">{html.escape(display)}</text>'
 for x,label in [(112,'HOLD'),(176,'RANGE'),(240,'REL'),(304,'Hz %'),(368,'SELECT')]:
  b+=text(x,165,label,10,blue if label=='SELECT' else ink)
  b+=f'<rect x="{x-19}" y="175" width="38" height="21" rx="3" fill="'+('#8eb8ee' if label=='SELECT' else '#aeb4bc')+'"/>'
 # Thin radial index dots; fixed labels remain readable when scaled to mobile.
 angles={'V':-165,'ohm':-135,'diode':-108,'cap':-88,'Hz':-68,'uA':-45,'mA':-15,'10A':15,'OFF':165,'OFF2':38}
 for a in angles.values():
  r=math.radians(a);x=240+87*math.cos(r);y=340+87*math.sin(r)
  b+=f'<circle cx="{x:.2f}" cy="{y:.2f}" r="2.7" fill="{ink}"/>'
 b+=text(121,310,'V',20,ink)
 b+=text(144,266,'Ω',20,ink)
 b+=line(177,236,187,236,ink,2)+f'<path d="M187 229L198 236L187 243Z M200 229V243 M200 236H208" fill="none" stroke="{ink}" stroke-width="2"/>'+line(227,225,237,225,ink,2)+line(237,217,237,233,ink,2)+line(243,217,243,233,ink,2)+line(243,225,253,225,ink,2)+text(281,239,'Hz',15,ink)
 for x,y,label in [(341,264,'4000 µA'),(359,308,'400 mA'),(358,365,'10 A')]:
  b+=text(x,y,label,16,ink)
 b+=text(119,384,'OFF',15,ink)+text(353,411,'OFF',15,ink)
 b+='<circle cx="240" cy="340" r="63" fill="#15191e" stroke="#626a74" stroke-width="3"/>'
 r=math.radians(angles[setting]);ux=math.cos(r);uy=math.sin(r)
 b+=f'<line x1="{240-22*ux:.2f}" y1="{340-22*uy:.2f}" x2="{240+43*ux:.2f}" y2="{340+43*uy:.2f}" stroke="#e1e5ea" stroke-width="13" stroke-linecap="round"/>'
 tip=(240+60*ux,340+60*uy);base=(240+43*ux,340+43*uy)
 b+=f'<polygon points="{tip[0]:.2f},{tip[1]:.2f} {base[0]-8*uy:.2f},{base[1]+8*ux:.2f} {base[0]+8*uy:.2f},{base[1]-8*ux:.2f}" fill="#f5bd18"/>'
 b+=text(140,469,'10A',18,ink)+text(240,469,'COM',18,ink)+text(340,450,'µA mA',16,ink)+text(340,470,'V Ω Hz',16,ink)
 for x,iscom in [(140,False),(240,True),(340,False)]:
  b+=f'<circle cx="{x}" cy="495" r="18" fill="#15191e" stroke="'+('#b7bfc7' if iscom else '#c55449')+'" stroke-width="4"/><circle cx="'+str(x)+'" cy="495" r="6" fill="#080b0e"/>'
 if black:
  b+='<path d="M240 495 C240 554 211 553 211 610" fill="none" stroke="#181c20" stroke-width="9" stroke-linecap="round"/><rect x="201" y="602" width="20" height="35" rx="4" fill="#252a31"/>'+line(211,637,211,651,'#6f7881',4)
 if red:
  x=140 if red=='10A' else 340
  b+=f'<path d="M{x} 495 C{x} 555 379 558 379 610" fill="none" stroke="#cf3931" stroke-width="9" stroke-linecap="round"/><rect x="369" y="602" width="20" height="35" rx="4" fill="#ba302b"/>'+line(379,637,379,651,'#6f7881',4)
 label='Multimeter med gul ram, mörk front och tre uttag: 10A, COM och µA mA V Ω Hz. Vredet pekar på '+setting+'.'
 if black:label+=' En sladd i COM.'
 if red:label+=' En sladd i '+('10A' if red=='10A' else 'µA mA V Ω Hz')+'.'
 return svg(b,label,480,665 if black or red else 570)
def mini(correct):
 b=(line(90,65,315,65)+line(365,65,435,65) if correct else line(90,65,435,65))+line(435,65,435,255)+line(435,255,90,255)+line(90,65,90,131)+line(90,189,90,255)+source(90,160,'6 V')+resistor(215,65,'R')
 if correct:
  b+='<circle cx="340" cy="65" r="25" fill="white" stroke="#292d31" stroke-width="3"/>'+text(340,72,'A',22)
 else:
  b+=line(180,65,180,160)+line(180,160,220,160)+line(270,160,310,160)+line(310,160,310,65)+'<circle cx="245" cy="160" r="25" fill="white" stroke="#292d31" stroke-width="3"/>'+text(245,167,'A',22)
 return svg(b,'Amperemeter '+('i serie med motståndet' if correct else 'parallellt med motståndet'))
def single():
 b=line(90,75,450,75)+line(450,75,450,255)+line(450,255,90,255)+line(90,75,90,136)+line(90,194,90,255)+source(90,165)+resistor(245,75,'300 Ω')
 return svg(b,'6 V spänningskälla ansluten till ett motstånd på 300 ohm.')
qs=[]
def add(title,level,kind,prompt,figure,options,answer,explanation,hint):
 qs.append(dict(id=f'MM-B{len(qs)+1:02}',title=title,traningsniva=level,kind=kind,course='fy1',area='Multimeter – koppla och mäta',miniräknare=True,geogebra=False,prompt=prompt,figure=figure,options=options,correct=answer,solution=explanation,hint=hint))
add('Spänningen över ett motstånd',1,'Koppla i kretsen','Du ska mäta spänningen över R₂. Mellan vilka punkter ska voltmeterns mätspetsar placeras? (Välj ett alternativ.)',series(),['A och E','B och C','B och F','A och C'],1,'B och C ligger på var sin sida om R₂. Voltmetern kopplas parallellt med motståndet. A och E ligger på samma ledning, liksom B och F. Mellan sådana punkter visar voltmetern 0 V.','Vilka punkter ligger på var sin sida om R₂?')
add('Spänningen över båda motstånden',2,'Koppla i kretsen','Du ska mäta den sammanlagda spänningen över R₁ och R₂. Mellan vilka punkter ska voltmetern kopplas? (Välj ett alternativ.)',series(),['B och F','B och C','A och E','A och C'],3,'A och C ligger på var sin sida om båda motstånden tillsammans. A och E ligger på samma ledning, liksom B och F. Inget av de punktparen ligger på var sin sida om motstånden.','Mätspetsarna ska omsluta båda motstånden.')
add('Strömmen i en gren',2,'Koppla i kretsen','Du ska mäta strömmen genom R₂. Vid vilken markering ska ledningen brytas och amperemetern sättas in? (Välj P, Q eller R.)',parallel(),['P','Q','R'],2,'Vid R går just strömmen genom R₂. Amperemetern sätts in i serie i den grenen. Vid P skulle den mäta strömmen genom båda grenarna tillsammans.','Följ den ledning som går genom R₂.')
add('Strömmen från batteriet',2,'Koppla i kretsen','Du ska mäta hela strömmen från spänningskällan. Var ska ledningen brytas och amperemetern sättas in? (Välj P, Q eller R.)',parallel(),['P','Q','R'],0,'P ligger före förgreningen, där hela strömmen passerar. Vid Q och R går bara strömmen i en av grenarna.','Var har strömmen ännu inte delats upp?')
add('Välj rätt kopplingsschema',1,'Koppla i kretsen','Vilken bild visar rätt koppling för att mäta strömmen genom motståndet? (Välj bild A eller B.)','<div class="pair"><div><b>Bild A</b>'+mini(False)+'</div><div><b>Bild B</b>'+mini(True)+'</div></div>',['Bild A','Bild B'],1,'I bild B går strömmen genom både motståndet och amperemetern. I bild A ligger amperemetern parallellt och ger en väg med mycket liten resistans förbi motståndet.','Strömmen som ska mätas måste gå genom amperemetern.')
add('Två uttag för spänningsmätning',1,'Välj uttag','Du ska mäta spänningen över ett batteri. Vilka två uttag ska sladdarna sitta i? (Välj ett alternativ.)',meter(),['COM och µA mA / V Ω Hz','COM och 10A','10A och µA mA / V Ω Hz'],0,'En sladd ska sitta i COM och den andra i det högra uttaget, som är märkt bland annat V.','Ett uttag är gemensamt för mätningarna. Det andra ska vara märkt med enheten volt.')
add('Den andra sladden',1,'Välj uttag','Du ska mäta spänningen över ett 9 V-batteri. En sladd sitter i COM. I vilket uttag ska den andra sitta? (Välj ett uttag.)',meter(black=True),['µA mA / V Ω Hz','10A','COM'],0,'Den andra sladden ska sitta i det högra uttaget, märkt bland annat V. Vredet ska stå på V.','Vilket uttag är märkt med enheten volt?')
add('Två uttag för en liten ström',1,'Välj uttag','Du ska mäta ungefär 85 mA och använda vredläget 400 mA. Vilka två uttag ska sladdarna sitta i? (Välj ett alternativ.)',meter(),['10A och µA mA / V Ω Hz','COM och 10A','COM och µA mA / V Ω Hz'],2,'En sladd ska sitta i COM och den andra i det högra uttaget, märkt µA och mA. 85 mA ryms inom 400 mA-området.','Ett uttag ska vara COM. Vilket av de andra passar för milliampere?')
add('Två uttag för en större ström',2,'Välj uttag','Du ska mäta en ström på ungefär 0,65 A. Vilka två uttag ska sladdarna sitta i? (Välj ett alternativ.)',meter(),['COM och µA mA / V Ω Hz','COM och 10A','10A och µA mA / V Ω Hz'],1,'0,65 A är 650 mA, vilket är större än 400 mA. Sladdarna ska därför sitta i COM och 10A. Vredet ska stå på 10 A.','Skriv strömmen i milliampere och jämför med märkningen vid vredet.')
add('Mät ett batteri',1,'Välj mätområde','Du ska mäta spänningen över ett 1,5 V-batteri. Sladdarna sitter som i bilden. Vilket läge ska vredet stå i? (Välj ett alternativ.)',meter(black=True,red='shared'),['V','Ω','400 mA','10 A'],0,'Vredet ska stå på V när du mäter spänning. Sladdarna sitter redan i rätt uttag.','Vilken bokstav står för enheten volt?')
add('En mycket liten ström',2,'Välj mätområde','En givare drar ungefär 250 µA. Sladdarna sitter som i bilden. Vilket av strömlägena ger bäst upplösning? (Välj ett alternativ.)',meter(black=True,red='shared'),['10 A','400 mA','4000 µA','V'],2,'Välj 4000 µA. 250 µA ryms i mikroampereområdet, som är känsligare än 400 mA och 10 A. Sladdarna sitter redan i rätt uttag.','Jämför enheten i frågan med de tre strömlägena.')
add('Två punkter på samma ledning',2,'Koppla i kretsen','Du kopplar voltmeterns mätspetsar till B och F. Vad visar voltmetern? (Välj ett alternativ.)',series(),['6 V','0 V','3 V','12 V'],1,'B och F ligger på samma ledning, utan någon komponent mellan sig. Spänningen mellan punkterna är därför 0 V. För att mäta spänningen över R₂ behöver en spets i stället sitta på andra sidan om R₂, exempelvis vid C.','Finns det någon komponent mellan B och F?')
add('Börja när strömmen är osäker',2,'Välj mätområde','Strömmen i en batterikrets uppskattas ligga mellan 0,1 A och 1,5 A. Sladdarna sitter som i bilden. Vilket läge ska du börja med? (Välj ett alternativ.)',meter(black=True,red='10A'),['4000 µA','400 mA','10 A','V'],2,'Välj 10 A. Det området rymmer hela det uppskattade intervallet. 400 mA motsvarar 0,4 A och kan vara för litet. Sladdarna sitter redan i COM och 10A.','Utgå från det största möjliga värdet.')
add('För stor ström för valt område',3,'Felsök mätningen','Du försöker mäta ungefär 0,65 A. Mätaren är kopplad i serie, men visar OL, vilket här betyder att mätområdet är överskridet. Du bryter strömmen. Vad behöver ändras före nästa mätning? (Välj ett alternativ.)',meter('OL','mA','shared',True,'mA'),['Bara vrida till 10 A.','Bara flytta sladden från högra uttaget till 10A.','Vrida till 4000 µA.','Flytta sladden från högra uttaget till 10A och vrida till 10 A.'],3,'650 mA är mer än 400 mA. Flytta sladden från det högra uttaget till 10A och vrid till 10 A. Sladden i COM sitter kvar. Både uttaget och vredläget måste passa den större strömmen.','Uttaget och vredläget måste passa ihop.')
add('Hela mätningen',3,'Kombinera val','Du ska mäta strömmen genom motståndet i 6 V-kretsen. Vilken uppställning ger bäst upplösning utan att området överskrids? (Välj ett alternativ.)','<div class="pair"><div>'+single()+'</div><div>'+meter()+'</div></div>',['COM och högra uttaget, vredet på V; parallellt med motståndet.','10A och högra uttaget, vredet på 400 mA; i serie med motståndet.','COM och högra uttaget, vredet på 400 mA; i serie med motståndet.','COM och 10A, vredet på 10 A; i serie med motståndet.'],2,'Strömmen är I = U/R = 6/300 A = 0,020 A = 20 mA. Det är 20 000 µA, så 4000 µA-området är för litet. Välj COM och det högra uttaget samt vredläget 400 mA. Mätaren kopplas i serie. 10 A-området skulle också rymma strömmen, men ger sämre upplösning.','Beräkna ungefär hur stor strömmen är innan du väljer uttag och område.')
add('Ett minustecken på skärmen',2,'Felsök mätningen','Du mäter ett batteri med sladdarna och inställningen i bilden. Skärmen visar −4,80 V. Vad ska du göra för att i stället visa +4,80 V? (Välj ett alternativ.)',meter('−4.80','V','shared',True,'V'),['Byta plats på mätspetsarna vid batteriet.','Flytta sladden från högra uttaget till 10A.','Vrida till 400 mA.','Trycka på HOLD.'],0,'Byt plats på mätspetsarna vid batteriet. Minustecknet visar att spetsen från COM sitter mot batteriets pluspol. Uttagen och V-läget kan vara kvar.','Tecknet beror på hur mätspetsarna är vända vid batteriet.')
(out/'uppgifter.json').write_text(json.dumps(qs,ensure_ascii=False,indent=2))
head='''<!doctype html><html lang="sv"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Multimeter – förslag B</title><style>
*{box-sizing:border-box}body{margin:0;background:#eef3f5;color:#182c43;font:17px/1.5 system-ui,sans-serif}header,main{max-width:1060px;margin:auto;padding:24px}header{padding-top:45px}h1{font-size:clamp(28px,5vw,44px);line-height:1.1;margin:10px 0}h2{font-size:23px;margin:10px 0}p{margin:10px 0}.eyebrow{color:#087c85;letter-spacing:.12em;font-size:13px;font-weight:750}nav{display:flex;gap:10px;flex-wrap:wrap;margin-top:22px}button,select{font:inherit;border-radius:9px;padding:10px 14px;border:1px solid #abbcc8;background:white;color:#182c43;cursor:pointer}article{background:white;padding:28px;border-radius:18px;margin:0 0 24px;border:1px solid #d4dfe6;break-inside:avoid}.meta{font-size:14px;color:#526778}.figure{max-width:480px;margin:20px auto}.figure:has(.pair){max-width:100%}svg{display:block;width:100%;height:auto} .pair{display:grid;grid-template-columns:1fr 1fr;gap:20px;align-items:center}.pair b{display:block;text-align:center} .options{display:grid;gap:9px}.option{text-align:left;display:flex;gap:12px}.option span{font-weight:700;color:#087c85}.option.chosen{outline:3px solid #087c85}.result{border-left:4px solid #087c85;background:#eef7f5;padding:12px 16px;margin-top:15px}.result.wrong{border-color:#b15b22;background:#fff5e9}details{margin-top:16px}summary{cursor:pointer;font-weight:600}.print-answer{display:none}footer{padding:25px;color:#526778;font-size:14px}.hidden{display:none}@media(max-width:650px){header,main{padding:16px}article{padding:18px}.pair{grid-template-columns:1fr}.pair svg{max-width:440px;margin:auto}}@media print{body{background:white;font-size:11pt}header{padding:0 10mm}header p,nav,.hint,.result,footer{display:none!important}main{padding:0}article{page-break-before:always;border:0;padding:0 10mm;border-radius:0}.figure{max-width:90mm;margin:5mm auto}.figure:has(.pair){max-width:170mm}.pair{grid-template-columns:1fr 1fr}h2{font-size:18pt}.option{padding:4px 8px;border:0}.options{gap:0}.print-answer{display:block;border-top:1px solid #bbb;margin-top:6mm;padding-top:3mm;font-size:10pt}button{cursor:auto}header{page-break-after:avoid}}
</style><header><div class="eyebrow">FYSIK 1 · JÄMFÖRELSEFÖRSLAG B</div><h1>Multimeter – koppla och mäta</h1><p>16 uppgifter med egna figurer. Välj ett svar för att prova, eller öppna facit. Inget resultat sparas.</p><p>Träna på var mätspetsarna ska placeras, vilka uttag som behövs och vilket läge vredet ska stå i.</p><nav><select id="filter" aria-label="Filtrera uppgiftstyp"><option value="">Alla uppgiftstyper</option>'''+''.join('<option>'+k+'</option>'for k in dict.fromkeys(q['kind']for q in qs))+'''</select><button onclick="window.print()">Skriv ut med facit</button><button id="reset">Börja om</button></nav></header><main>'''
body=''
for q in qs:
 opts=''.join(f'<button class="option" data-choice="{i}">{html.escape(o)}</button>'for i,o in enumerate(q['options']))
 body+=f'''<article id="{q['id']}" data-kind="{q['kind']}" data-answer="{q['correct']}"><div class="meta">{q['id']} · Nivå {q['traningsniva']} · {q['kind']}</div><h2>{q['title']}</h2><p>{q['prompt']}</p><div class="figure">{q['figure']}</div><div class="options">{opts}</div><div class="result" hidden aria-live="polite"></div><details class="hint"><summary>Ledtråd</summary><p>{q['hint']}</p></details><details class="hint"><summary>Visa facit</summary><p><b>{html.escape(q['options'][q['correct']])}</b></p><p>{q['solution']}</p></details><div class="print-answer"><b>Facit: {html.escape(q['options'][q['correct']])}</b><br>{q['solution']}</div></article>'''
script='''</main><footer>Jämförelseförslag • Lokala förslags-ID:n • Inte infört i uppgiftsbanken • Miniräknare tillåten, GeoGebra behövs inte.</footer><script>
document.querySelectorAll('.option').forEach(b=>b.addEventListener('click',()=>{const a=b.closest('article'),r=a.querySelector('.result'),correct=b.dataset.choice===a.dataset.answer;a.querySelectorAll('.option').forEach(x=>x.classList.remove('chosen'));b.classList.add('chosen');r.hidden=false;r.classList.toggle('wrong',!correct);r.textContent=correct?'Rätt! '+a.querySelectorAll('details p')[2].textContent:'Det stämmer inte. Prova igen eller öppna ledtråden.';}));document.querySelector('#filter').addEventListener('change',e=>document.querySelectorAll('article').forEach(a=>a.classList.toggle('hidden',e.target.value!==''&&a.dataset.kind!==e.target.value)));document.querySelector('#reset').addEventListener('click',()=>{document.querySelectorAll('.result').forEach(r=>r.hidden=true);document.querySelectorAll('.chosen').forEach(x=>x.classList.remove('chosen'));document.querySelectorAll('details').forEach(d=>d.open=false);});
</script></html>'''
(out/'index.html').write_text(head+body+script)

# Exportera varje figur separat för återanvändning i uppgiftsbankerna.
import re
asset_dir=out/'figurer'
asset_dir.mkdir(exist_ok=True)
for q in qs:
 for i,figure in enumerate(re.findall(r'<svg\b.*?</svg>',q['figure'],re.S),1):
  (asset_dir/(q['id']+'-'+str(i)+'.svg')).write_text(figure)
(out/'multimeter.svg').write_text(meter('0.213','mA','shared',True,'mA'))
