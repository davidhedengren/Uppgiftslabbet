# Multimeter – förslag B, aktuellt jämförelseunderlag

## Senaste användarbeslut

- Allt utgår från samma strömtyp. Orden likström, växelström, likspänning, växelspänning och DC/AC används inte i elevinnehållet. Motsvarande småmarkeringar i den pedagogiska SVG-modellen har dolts.
- Sladdfärger avgör inte rätt eller fel. Frågor och facit beskriver uttagen, eller sladden som redan sitter i ett visst uttag. Figurerna får fortfarande visa sladdar i olika färger för att de ska vara lätta att följa.
- B06, B08, B09 och B15 kräver val av båda uttagen. Inga sladdar är anslutna i dessa figurer. B15 kombinerar även vredläge och serie-/parallellkoppling.
- A/E respektive B/F är närliggande punkter på samma ledning. De används som avsiktliga, fysikaliskt rimliga felalternativ i B01–B02. B12 prövar förståelsen att voltmetern då visar 0 V.

## Leverans

- `index.html`: klickbar förhandsvisning med svar, ledtrådar och facit.
- `multimeter-forslag-b.pdf`: alla 16 uppgifter med facit.
- `multimeter.svg`, `multimeter.png` och `figurer/`: översikt samt individuella figurer.
- `uppgifter.json`: förslagsdata, ännu inte importerade i banken.
- `build.py` och `verify-content.py`: reproducerbar konstruktion och innehållskontroller.

## Granskade uppgifter

| ID | Nivå | Uppgift | Facit |
|---|---|---|---|
| MM-B01 | 1 | Spänningen över ett motstånd | B och C |
| MM-B02 | 2 | Spänningen över båda motstånden | A och C |
| MM-B03 | 2 | Strömmen i en gren | R |
| MM-B04 | 2 | Strömmen från batteriet | P |
| MM-B05 | 1 | Välj rätt kopplingsschema | Bild B |
| MM-B06 | 1 | Två uttag för spänningsmätning | COM och µA mA / V Ω Hz |
| MM-B07 | 1 | Den andra sladden | µA mA / V Ω Hz |
| MM-B08 | 1 | Två uttag för en liten ström | COM och µA mA / V Ω Hz |
| MM-B09 | 2 | Två uttag för en större ström | COM och 10A |
| MM-B10 | 1 | Mät ett batteri | V |
| MM-B11 | 2 | En mycket liten ström | 4000 µA |
| MM-B12 | 2 | Två punkter på samma ledning | 0 V |
| MM-B13 | 2 | Börja när strömmen är osäker | 10 A |
| MM-B14 | 3 | För stor ström för valt område | Flytta sladden från högra uttaget till 10A och vrida till 10 A. |
| MM-B15 | 3 | Hela mätningen | COM och högra uttaget, vredet på 400 mA; i serie med motståndet. |
| MM-B16 | 2 | Ett minustecken på skärmen | Byta plats på mätspetsarna vid batteriet. |

## Utfall

Alla 16 kort är granskade. B01–B02 har nya distraktorer och punkter. B06–B16 har anpassad terminologi, uttagsfrågor, alternativ och lösningar. B12 är omarbetad till spänningsmätning mellan två närliggande punkter. B03–B05 är granskade utan nytt sakfel. Inga produktionsrapporter behandlas, så rapportkommentarer är inte aktuella.

Den gula treuttagsmodellen behåller 4000 µA, 400 mA och 10 A samt V-läge. Beräkningarna 0,65 A = 650 mA och 6/300 A = 20 mA är verifierade. Miniräknare tillåten i alla kort; GeoGebra behövs inte.

## Verifiering

- Sex innehållstester omfattar metadata, strömområden, förbjudna elevtermer/färgregler, obesvarade uttag i bilderna samt potentialskillnader mellan de nya punktparen.
- 112 rättningskontroller över 32 mobil-/datorvyer i prototypen. Inga JavaScript-fel eller sidöverbredd.
- Elva unika SVG-figurer utan varningar/fel. Punktplacering och tomma uttag även visuellt kontrollerade.
- Ingen bankimport, commit eller push gjord. Konsumenttest i Kunskapsgymmet behövs vid eventuell import.
